package com.example.communitycleanup.HomeActivities.CheckOut;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.communitycleanup.R;

public class NoCheckOut extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_check_out);
    }
}
